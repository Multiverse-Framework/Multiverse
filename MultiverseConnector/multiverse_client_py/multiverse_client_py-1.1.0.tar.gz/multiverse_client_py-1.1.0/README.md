# Multiverse-ClientPy #

[![Build Status](https://bitbucket.org/vinrobotics/multiverse-clientpy/badges/pipeline.svg)](https://bitbucket.org/vinrobotics/multiverse-clientpy/pipelines)

**multiverse_client_py** is a Python client library for interacting with the **Multiverse API**.
It provides a **simple, efficient, and well-integrated** way to connect to Multiverse services and embed them into your Python applications.

The package includes **native Python bindings** for high-performance communication with the Multiverse core.

---

## 🧩 Requirements

| Item      | Requirement                |
|-----------|----------------------------|
| 🐍 Python | 3.8+                       |
| 💻 OS     | Ubuntu 22.04+ / Windows 11 |

---

## 📦 Installation

> ⚠️ This step assumes you are using **virtualenv** for Python package installation.

### 1️⃣ Clone the repository

```bash
git clone https://<your_user_name>@bitbucket.org/vinrobotics/multiverse-clientpy.git
cd multiverse-clientpy
```

### 2️⃣ Install the package (development mode)

```bash
pip install -e .
```

---

## ✅ Verify installation

```bash
python -c "import multiverse_client_py as m; print(f'Multiverse-ClientPy v{m.__version__} installed successfully 🚀')"
```

If no error is raised, the installation was successful.

---

## 🧪 Tests

Run the following commands to test the software locally:

```bash
# Test against the Rust-based Multiverse Server
python3 -m unittest tests.test_multiverse_client.MultiverseClientRustTestCase

# Test against the C++-based Multiverse Server
python3 -m unittest tests.test_multiverse_client.MultiverseClientCppTestCase
```

---